export const config = {
    site_name: "Cryptotrades",
    media_path: "https://exampleapi.com",
    base_url: "https://exampleadmin.com",
    frontend_url: "https://example.com"
}